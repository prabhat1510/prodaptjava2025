package com.blueyonder.exercise;

public enum OrderStatus {
    NEW,
    DELIVERED,
    PENDING
}
