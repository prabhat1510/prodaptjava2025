package com.blueyonder.enumexample;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

