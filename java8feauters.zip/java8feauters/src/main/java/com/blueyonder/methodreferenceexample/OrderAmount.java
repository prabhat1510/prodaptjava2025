package com.blueyonder.methodreferenceexample;

public interface OrderAmount {
    Order getOrderAmount(Double amount);
}
