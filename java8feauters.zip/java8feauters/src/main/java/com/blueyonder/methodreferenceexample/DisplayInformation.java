package com.blueyonder.methodreferenceexample;

public interface DisplayInformation {

    public void display();
}
