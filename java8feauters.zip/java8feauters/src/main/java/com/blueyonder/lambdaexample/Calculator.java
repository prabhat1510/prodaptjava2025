package com.blueyonder.lambdaexample;

@FunctionalInterface
public interface Calculator {

    public Integer compute(Integer num1,Integer num2);

    //public void display(int result);
}
