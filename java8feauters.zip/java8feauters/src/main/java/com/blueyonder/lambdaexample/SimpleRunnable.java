package com.blueyonder.lambdaexample;

public class SimpleRunnable implements Runnable {

    @Override
    public void run() {
        System.out.println("Hello I am into run method of SimpleRunnable class");
    }

}

