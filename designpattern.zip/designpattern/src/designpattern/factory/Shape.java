package designpattern.factory;

public interface Shape {
	void draw();
}
