package designpattern.decorator;

public interface Car {
	public void assemble();
}
