package designpattern.cake;

public class CakeDemo {

	public static void main(String[] args) {
	
	}

}
