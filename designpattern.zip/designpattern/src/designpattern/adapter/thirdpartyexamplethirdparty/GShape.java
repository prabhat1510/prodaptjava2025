package designpattern.adapter.thirdpartyexamplethirdparty;

public interface GShape {
	double area();
	double perimeter();
	void drawShape();
}
