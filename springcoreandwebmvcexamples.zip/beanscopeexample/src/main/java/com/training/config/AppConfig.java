package com.training.config;

import com.training.beans.Address;
import com.training.beans.Product;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan("com.training")
public class AppConfig {
    @Bean(name="product")
    @Scope("prototype")
    public Product getProduct() {
        return new Product();
    }

    //@Bean(name="homeAddress")
    @Bean
    public Address homeAddress() {
        return new Address();
    }

    @Bean
    public Address workAddress() {
        return new Address();
    }
    @Bean
    public Address weekEndAddress() {
        return new Address();
    }

}
