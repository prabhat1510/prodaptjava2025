package com.training.mainapp;

import com.training.beans.Address;
import com.training.beans.Customer;
import com.training.config.AppConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        // Creating IOC Container
        ApplicationContext context4 = new AnnotationConfigApplicationContext(AppConfig.class);
        // Getting Bean
        Address workAddressBean = (Address) context4.getBean("workAddress", Address.class);
        Address homeAddressBean = (Address) context4.getBean("homeAddress", Address.class);
        Address weekEndAddressBean = (Address) context4.getBean("weekEndAddress", Address.class);
        System.out.println(workAddressBean.hashCode());
        System.out.println(homeAddressBean.hashCode());
        System.out.println(weekEndAddressBean.hashCode());
        Customer customer = context4.getBean("customer",Customer.class);
        System.out.println(customer);
    }
}
