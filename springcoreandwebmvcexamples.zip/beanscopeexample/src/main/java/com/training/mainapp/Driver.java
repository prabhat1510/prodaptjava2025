package com.training.mainapp;

import com.training.beans.Product;
import com.training.config.AppConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;


public class Driver {
    public static void main(String[] args) {
        // Creating IOC Container
        ApplicationContext context4 = new AnnotationConfigApplicationContext(AppConfig.class);
        // Getting Bean
        Product prodBean = (Product) context4.getBean("product");
        System.out.println(prodBean);
        System.out.println(prodBean.hashCode());
        Product prodBean1 = (Product) context4.getBean("product");
        System.out.println(prodBean1);
        System.out.println(prodBean1.hashCode());
        // Closing the context
        ((AbstractApplicationContext) context4).registerShutdownHook();
    }
}
