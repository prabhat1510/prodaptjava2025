package com.training.constructorinject;

public interface IAddress {
	//abstract method
}
