package com.training.constructorinject;

public class MainApp {
    public static void main(String[] args) {
        Address address = new Address();
        Customer customer = new Customer(address);
    }
}
