package com.training.constructorinject;

public interface IAddressInjector {
	void injectAddress(IAddress address);
}
