package com.training.constructorinject;

public class Address implements IAddress {
		private Integer addressId;
}
