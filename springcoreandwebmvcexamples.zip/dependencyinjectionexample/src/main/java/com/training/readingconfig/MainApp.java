package com.training.readingconfig;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        // configuration metadata
        String springConfigurationFile = "springconfig.xml";

        // Instantiating a Spring IoC container
        AbstractApplicationContext context = new ClassPathXmlApplicationContext(springConfigurationFile);
        // Here using context.getBean method we are trying to get instance of Customer
        // class
        Person person = context.getBean("person", Person.class);
        System.out.println(person);
        System.out.println(person.hashCode());
        Person person1 = context.getBean("person1", Person.class);
        System.out.println(person1);
        System.out.println(person1.hashCode());
        context.close();
        System.out.println("******BeanFactory is an implementation of Spring Container************");
        BeanFactory factory = new ClassPathXmlApplicationContext(springConfigurationFile);
        Customer customer = factory.getBean("customer",Customer.class);

        // Here using factory.getBean method we are trying to get instance of Customer
        // class
        Customer cust = factory.getBean("customer", Customer.class);
        // Using cust object/bean instance we are accessing the object method
        System.out.println(cust.getCustomerId());
        System.out.println(cust.getCustomerName());
        System.out.println(cust.getHomeAddress().getCity());
        System.out.println(cust.getResAddress().getCity());

    }
}
