package com.training.config;

import com.training.beans.Book;
import com.training.processor.MyBeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;



@Configuration
//com.training is a base package where IOC container will look up for all POJO classes
@ComponentScan("com.training")
public class AppConfig {

	@Bean(name = "bookBean")
	public static Book getBookBean() {
		return new Book();
	}

	@Bean
	public MyBeanPostProcessor myBeanPostProcessor() {
		return new MyBeanPostProcessor();
	}

	/*
	 * @Bean(initMethod = "initMethod", destroyMethod = "destroyMethod") public
	 * MySpringBean mySpringBean(){ return new MySpringBean(); }
	 */
}