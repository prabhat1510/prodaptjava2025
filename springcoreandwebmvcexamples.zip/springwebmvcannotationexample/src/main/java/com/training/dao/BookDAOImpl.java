package com.training.dao;

import com.training.dto.BookDTO;
import com.training.exceptions.BookNotFoundException;
import com.training.utility.HibernateUtility;
import jakarta.transaction.Transactional;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BookDAOImpl implements BookDAO {
    Session session = HibernateUtility.getSessionFactory().openSession();

    @Override
    @Transactional
    public BookDTO addBook(BookDTO bookDTO) {

        session.persist(bookDTO);

        return bookDTO;
    }


    @Override
    @Transactional
    public BookDTO bookById(Integer bookId) throws BookNotFoundException {
        BookDTO bookDTO = session.get(BookDTO.class, bookId);
        if (bookDTO != null) {
            return bookDTO;
        } else {
            throw new BookNotFoundException("Book with bookId " + bookId + " doesn't exists");
        }

    }

    @Override
    @Transactional
    public BookDTO bookByName(String bookName) throws BookNotFoundException {
        BookDTO bookDTO = session.get(BookDTO.class, bookName);
        if (bookDTO != null) {
            return bookDTO;
        } else {
            throw new BookNotFoundException("Book with bookName " + bookName + " doesn't exists");
        }
    }


    @Override
    public List<BookDTO> bookByPublisher(String publisher) throws BookNotFoundException {
        return List.of();
    }

    @Override
    public List<BookDTO> books() throws BookNotFoundException {
        return List.of();
    }

    @Override
    public String deleteById(Integer bookId) throws BookNotFoundException {
        return "";
    }

    @Override
    public String deleteByBookName(String bookName) throws BookNotFoundException {
        return "";
    }

    @Override
    public BookDTO updateBook(BookDTO bookDTO) {
        return null;
    }
}
