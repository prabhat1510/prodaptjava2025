package com.training.ui;

import com.training.entities.Employee;
import com.training.exceptions.EmployeeNotFoundException;
import com.training.service.EmployeeService;
import com.training.service.EmployeeServiceImpl;

public class MainApp {
    /**
    public static void main(String[] args) {
        //Data to be persisted
        Employee employee = new Employee();
        employee.setFirstName("Raju");
        employee.setLastName("Pal");
        employee.setEmail("raju@gmail.com");

        //Creating an instance of Service Impl
        EmployeeService empService = new EmployeeServiceImpl();
        //Calling the create method of employee service
        Employee emp=empService.create(employee);
        System.out.println(emp);

        //Retrieve
        System.out.println(empService.retrieve(2));

        //Employee Update
        Employee emp2 = new Employee();
        emp2.setFirstName("Sohan");
        emp2.setLastName("Pal");
        emp2.setId(2);
        System.out.println(empService.update(emp2));
    }**/
    public static void main(String[] args) {
        //Creating an instance of Service Impl
        EmployeeService empService = new EmployeeServiceImpl();
        try {
            System.out.println(empService.findByEmail("raju@gmail.com"));
        }catch(EmployeeNotFoundException e){
            System.out.println(e.getMessage());
        }
        System.out.println(empService.findAll());
    }
}
