package com.training.ui;

import com.training.entities.Book;
import com.training.service.BookService;
import com.training.service.BookServiceImpl;

public class BookMainApp {
    public static void main(String[] args) {
        BookService bookService = new BookServiceImpl();
        /*Book book = new Book();
        book.setBookName("Mahabharata");
        book.setBookAuthor("Ved Vyas");
        book.setBookISBN("Mah1311Vyas2025");
        bookService.addBook(book);*/
        System.out.println(bookService.findAll());
        System.out.println(bookService.findByAuthor("Ved Vyas"));

    }
}
