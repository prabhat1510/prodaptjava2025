package com.training.dao;

import com.training.entities.Book;
import com.training.exceptions.BookNotFoundException;

import java.util.List;

public interface BookDAO {
    //Create
    public Book addBook(Book book);
    //Retrieve
    public Book getBookById(Integer id) throws BookNotFoundException;
    //Update
    public Book update(Book book);
    //Delete
    public void delete(Integer id) throws BookNotFoundException;

    //Retrieve By author
    public List<Book> findByAuthor(String author) throws BookNotFoundException;
    //Retrieve all books
    public List<Book> findAll();


}