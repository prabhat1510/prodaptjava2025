package com.training.dao;

import com.training.entities.Employee;
import com.training.exceptions.EmployeeNotFoundException;
import jakarta.persistence.*;

import java.util.List;

public class EmployeeDAOImpl implements EmployeeDAO {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaexample");
    EntityManager em = emf.createEntityManager();


    @Override
    public Employee create(Employee employee) {
        em.getTransaction().begin();
        em.persist(employee); //save the datas
        em.getTransaction().commit();
        /*em.close();
        emf.close();*/
        return employee;
    }

    @Override
    public Employee retrieve(Integer id) {
        em.getTransaction().begin();
        Employee emp = em.find(Employee.class, id);
        em.getTransaction().commit();
        /*em.close();
        emf.close();*/

        return emp;
    }

    @Override
    public Employee update(Employee employee) {
        em.getTransaction().begin();
        Employee emp = em.find(Employee.class, employee.getId());
        if (emp != null) {
            em.merge(employee);
        }
        em.getTransaction().commit();

        return employee;
    }

    @Override
    public void delete(Integer id) {
        //Delete data in database using remove method of EntityManager

        em.getTransaction().begin();
        Employee emp = em.find(Employee.class, id);
        if(emp !=null) {
            em.remove(emp);
        }
        em.getTransaction().commit();
        /*em.close();
        emf.close();*/
    }

    @Override
    public Employee findByEmail(String email) throws EmployeeNotFoundException {
        em.getTransaction().begin();
        Query q = em.createQuery("select e from Employee e where e.email = :email");
        q.setParameter("email", email);
        Employee emp = (Employee) q.getSingleResultOrNull();
        em.getTransaction().commit();
        if(emp!=null) {
            return emp;
        }else{
            throw new EmployeeNotFoundException("Employee with email id "+email+" not found in our records");
        }

    }

    @Override
    public List<Employee> findAll() {
        Query query = em.createQuery("SELECT emp from Employee emp");
        return query.getResultList();
    }

    @Override
    public List<Employee> getEmployeesUsingTypedQuery() {
        TypedQuery<Employee> query =em.createQuery("SELECT emp from Employee emp", Employee.class);
        return query.getResultList();
    }



    @Override
    public void updateEmployeeUsingQuery(Employee employee) {
        em.getTransaction().begin();
        Query query = em.createQuery("UPDATE Employee emp  SET emp.lastName =?1 where emp.id=?2");
        query.setParameter(2, employee.getId());
        query.setParameter(1, employee.getLastName());
        int row = query.executeUpdate();
        em.getTransaction().commit();
        System.out.println("Number of updated row is ---"+row);
    }
}
