package com.training.service;

import com.training.dao.EmployeeDAO;
import com.training.dao.EmployeeDAOImpl;
import com.training.entities.Employee;
import com.training.exceptions.EmployeeNotFoundException;

import java.util.List;

public class EmployeeServiceImpl implements EmployeeService {
    private EmployeeDAO dao = new EmployeeDAOImpl();
    @Override
    public Employee create(Employee employee) {
        return dao.create(employee);
    }

    @Override
    public Employee retrieve(Integer id) {
        return dao.retrieve(id);
    }

    @Override
    public Employee update(Employee employee) {
        return dao.update(employee);
    }

    @Override
    public void delete(Integer id) {
        dao.delete(id);
    }

    @Override
    public Employee findByEmail(String email) throws EmployeeNotFoundException {
        return dao.findByEmail(email);
    }

    @Override
    public List<Employee> findAll() {
        return dao.findAll();
    }

    @Override
    public List<Employee> getEmployeesUsingTypedQuery() {
        return dao.getEmployeesUsingTypedQuery();
    }

    @Override
    public void updateEmployeeUsingQuery(Employee employee) {
        dao.updateEmployeeUsingQuery(employee);
    }
}
