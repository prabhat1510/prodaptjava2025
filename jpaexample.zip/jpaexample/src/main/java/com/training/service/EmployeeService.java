package com.training.service;

import com.training.entities.Employee;
import com.training.exceptions.EmployeeNotFoundException;

import java.util.List;

public interface EmployeeService {
    //Create
    public Employee create(Employee employee);
    //Retrieve
    public Employee retrieve(Integer id);
    //Update
    public Employee update(Employee employee);
    //Delete
    public void delete(Integer id);

    //Retrieve By email
    public Employee findByEmail(String email) throws EmployeeNotFoundException;
    //Retrieve all employee
    public List<Employee> findAll();

    //Example of Typed Query
    public List<Employee> getEmployeesUsingTypedQuery();

    //Update using Query
    public void updateEmployeeUsingQuery(Employee employee);
}
