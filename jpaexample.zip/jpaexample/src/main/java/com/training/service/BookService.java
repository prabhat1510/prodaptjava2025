package com.training.service;

import com.training.entities.Book;
import com.training.entities.Employee;
import com.training.exceptions.BookNotFoundException;
import com.training.exceptions.EmployeeNotFoundException;

import java.util.List;

public interface BookService {
    //Create
    public Book addBook(Book book);
    //Retrieve
    public Book getBookById(Integer id) throws BookNotFoundException;
    //Update
    public Book update(Book book);
    //Delete
    public void delete(Integer id) throws BookNotFoundException;

    //Retrieve By author
    public List<Book> findByAuthor(String author) throws BookNotFoundException;
    //Retrieve all books
    public List<Book> findAll();


}
