package com.training.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name="emp_details")
public class Employee {
    @Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="emp_id")
    private Integer id;
    @Column(name="f_name")
    private String firstName;
    @Column(name="l_name")
    private String lastName;
    private String email;
}
