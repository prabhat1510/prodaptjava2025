package com.training.onetomanybi;

import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

import static jakarta.persistence.CascadeType.*;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name="dept_details")
@ToString
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="dept_id")
    private Integer id;
    private String name;

    @OneToMany(mappedBy = "department",cascade = {CascadeType.PERSIST, CascadeType.MERGE}) //inverse side
    @ToString.Exclude
    private Set<Employee> employees;
}
