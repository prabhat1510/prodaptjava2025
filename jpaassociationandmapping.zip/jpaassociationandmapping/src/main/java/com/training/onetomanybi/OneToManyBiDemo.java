package com.training.onetomanybi;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.HashSet;
import java.util.Set;

public class OneToManyBiDemo {
    public static void main(String[] args) {
        Department department = new Department();
        department.setName("Admin");


        Employee employee = new Employee();
        employee.setDepartment(department);
        employee.setName("Ajeet Kumar");

        Employee employee1 = new Employee();
        employee1.setDepartment(department);
        employee1.setName("Rajnikanth");

        Set<Employee> empSet = new HashSet<Employee>();
        empSet.add(employee1);
        empSet.add(employee);
        department.setEmployees(empSet);

        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaexample");
        //Create EM
        EntityManager em = emf.createEntityManager();
        //Begin Transaction
        em.getTransaction().begin();
        //em.persist(employee);
        //em.persist(employee1);
        em.persist(department);
        /**Employee emp = em.find(Employee.class, 2);
        System.out.println("Employee ID: " + emp.getId()+" Name: "+emp.getName());
       **/ //Commit Transaction
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
}
