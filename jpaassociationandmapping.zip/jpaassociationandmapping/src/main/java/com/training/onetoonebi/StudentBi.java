package com.training.onetoonebi;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name="student_bi")
public class StudentBi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer studentId;
    private String studentName;

    // Student class has an address -- HAS A relationship
    // ONe to One bi
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(
            name="address_id", unique=true, nullable=false)
    private AddressBi addressBi; // owning side
}