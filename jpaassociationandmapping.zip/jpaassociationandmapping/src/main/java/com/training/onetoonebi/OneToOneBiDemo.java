package com.training.onetoonebi;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class OneToOneBiDemo {

    public static void main(String[] args) {
        StudentBi studentBi = new StudentBi();
        AddressBi homeAddressBi = new AddressBi();

        studentBi.setStudentName("Suman Sarkar");
        homeAddressBi.setCity("Kolkatta");
        homeAddressBi.setState("West Bengal");
        homeAddressBi.setStreet("New Town");
        homeAddressBi.setZipCode("330001");

        //inject address into student
        studentBi.setAddressBi(homeAddressBi);
        homeAddressBi.setStudentBi(studentBi);
        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaexample");
        //Create EM
        EntityManager em = emf.createEntityManager();
        //Begin Transaction
        em.getTransaction().begin();
        //
        //em.persist(studentBi);
        StudentBi  stud=em.find(StudentBi.class, 1);
        System.out.println("Student "+stud);
        //Commit Transaction
        em.getTransaction().commit();
        em.close();
        emf.close();

    }

}
