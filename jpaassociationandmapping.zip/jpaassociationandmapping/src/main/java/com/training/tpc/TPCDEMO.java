package com.training.tpc;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class TPCDEMO {
    public static void main(String[] args) {
        EmployeeTPC e1 = new EmployeeTPC();
        e1.setName("Smith");
        e1.setSalary(67865.50);

        ManagerTPC m1 =new ManagerTPC();
        m1.setDepartmentName("Accounts");
        m1.setName("Ravi Kumar");
        m1.setSalary(123456.00);
        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaexample");
        //Create EM
        EntityManager em = emf.createEntityManager();
        //Begin Transaction
        em.getTransaction().begin();
        em.persist(e1);
        em.persist(m1);

        //Commit Transaction
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
}
