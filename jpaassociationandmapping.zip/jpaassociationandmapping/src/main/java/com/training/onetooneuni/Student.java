package com.training.onetooneuni;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name="student_info")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer studentId;
    private String studentName;
    //Student class has an address -- HAS A relationship
    //ONe to One uni
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(
            name="address_id", unique=true, nullable=false)
    private Address address; //Address type property address is written here
}