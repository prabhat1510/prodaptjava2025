package com.training.onetooneuni;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class OneToOneUniDemo {
    public static void main(String[] args) {
        Student student = new Student();
        Address homeAddress = new Address();

        student.setStudentName("Suman Sarkar");
        student.setStudentId(1);
        homeAddress.setCity("Kolkatta");
        homeAddress.setState("West Bengal");
        homeAddress.setStreet("New Town");
        homeAddress.setZipCode("330001");
        homeAddress.setAddressId(1);
        //inject address into student
        student.setAddress(homeAddress);
        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaexample");
        //Create EM
        EntityManager em = emf.createEntityManager();
        //Begin Transaction
        em.getTransaction().begin();
        //Do db operation
        //em.persist(student);
        //Address address =em.find(Address.class,1);
        //em.remove(address);
        Student student1 = em.find(Student.class, 1);
        em.remove(student1);
        //Commit Transaction
        em.getTransaction().commit();
        em.close();
        emf.close();

    }
}
