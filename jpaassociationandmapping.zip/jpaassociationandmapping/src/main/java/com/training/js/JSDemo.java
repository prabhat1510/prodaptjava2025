package com.training.js;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;




public class JSDemo {

	public static void main(String[] args) {
		
		EmployeeJS e1 = new EmployeeJS();
		e1.setName("Smith");
		e1.setSalary(67865.50);
		
		ManagerJS m1 =new ManagerJS();
		m1.setDepartmentName("Accounts");
		m1.setName("Ravi Kumar");
		m1.setSalary(123456.00);

        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaexample");
        //Create EM
        EntityManager em = emf.createEntityManager();
        //Begin Transaction
        em.getTransaction().begin();
        em.persist(e1);
        em.persist(m1);

        //Commit Transaction
        em.getTransaction().commit();
        em.close();
        emf.close();

	}

}
