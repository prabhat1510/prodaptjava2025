package com.training.functionalinterface;
@FunctionalInterface
public interface CalculatorFuncInterface {
    double pi=3.14;
    public int add(int a, int b);
    //public int sub(int a, int b);
    public default int multiply(int a, int b) {
        return a * b;
    }
    public static void display() {
        System.out.println("display method of functionalinterface");
    }

    public default void displayDefault() {
        System.out.println("display default method of functionalinterface");
    }
    public static void displayMessage() {
        System.out.println("display message method of functionalinterface");
    }

}
