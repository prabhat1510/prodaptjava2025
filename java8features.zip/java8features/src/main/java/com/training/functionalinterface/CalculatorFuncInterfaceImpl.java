package com.training.functionalinterface;

public class CalculatorFuncInterfaceImpl implements CalculatorFuncInterface {
    @Override
    public int add(int a, int b) {
        return a+b;
    }
    //Default methods of a functional interface is getting overridden
    @Override
    public int multiply(int a, int b) {
        return CalculatorFuncInterface.super.multiply(a, b);
    }

    @Override
    public void displayDefault() {
        CalculatorFuncInterface.super.displayDefault();
    }
}
