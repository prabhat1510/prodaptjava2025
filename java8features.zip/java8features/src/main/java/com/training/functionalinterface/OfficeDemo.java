package com.training.functionalinterface;

import java.util.*;

public class OfficeDemo {
    public static void main(String[] args) {
        //List of number
        // List<Integer> listOfNumber = new ArrayList<Integer>();
        //listOfNumber.add(1);
        List<Integer> listOfNumber = Arrays.asList(2,3,1,4,5,6,7);
        //Using forEach i want to print the numbers
        System.out.println("***************lambda expression******************");
        listOfNumber.forEach((n)->System.out.println(n));
        System.out.println("***************Advanced for loop******************");
        for(Integer n:listOfNumber){
            System.out.println(n);
        }
        System.out.println("***************MEthod Reference******************");
        listOfNumber.forEach(System.out::println);
        System.out.println("****************Iterator******************");
        Iterator<Integer> iterator = listOfNumber.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }

        System.out.println("***************************************");
        //Check odd and even from a collection using lambda expression
        listOfNumber.forEach((n)->{
            if(n%2 == 0) {
                System.out.println(n+" is an even number");
            }else {
                System.out.println(n+" is an odd number");
            }
        });
        System.out.println("***************************************");
        CalculatorFuncInterface calc = (a,b)->a+b;//implementation of abstract method add of functional interface
        System.out.println(calc.add(1,2));
        calc.displayDefault();
        calc.multiply(10,20);
        CalculatorFuncInterface.displayMessage();
        CalculatorFuncInterface.display();
        System.out.println("***************************************");
        System.out.println("**************Sorting elements of collection using lambda*******************");
        Office office = new Office();
        office.setOfficeId(1);
        office.setBlock("A");
        office.setBuildingName("IITM Research Park");
        office.setCity("Chennai");
        office.setArea("Taramani");

        Office office1 = new Office();
        office1.setOfficeId(2);
        office1.setBlock("Fidelity Block");
        office1.setBuildingName("Ramanujan SEZ");
        office1.setCity("Chennai");
        office1.setArea("Taramani");

        Office office2 = new Office();
        office2.setOfficeId(3);
        office2.setBlock("Industrial Estate");
        office2.setBuildingName("Guindy IE");
        office2.setCity("Chennai");
        office2.setArea("Guindy");

        Office office3 = new Office();
        office3.setOfficeId(4);
        office3.setBlock("Jupiter");
        office3.setBuildingName("IPTL");
        office3.setCity("BLR");
        office3.setArea("Whitefield");

        List<Office> officeList= new ArrayList<Office>();
        officeList.add(office3);
        officeList.add(office2);
        officeList.add(office1);
        officeList.add(office);
        System.out.println(officeList);
        System.out.println("*********Instead of custom comparator for block "
                + "we are using lambda***********************************");
        Collections.sort(officeList, Comparator.comparing((o)->o.getBlock()));
        System.out.println(officeList);

        System.out.println("**********Instead of custom comparator for area we "
                + "are using Method reference**********************************");
        Collections.sort(officeList, Comparator.comparing(Office::getArea));
        System.out.println("********************************************");
        System.out.println(officeList);

    }
}
