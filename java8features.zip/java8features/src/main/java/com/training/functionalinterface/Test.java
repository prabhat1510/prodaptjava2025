package com.training.functionalinterface;

public class Test {
    public static void main(String[] args) {
        CalculatorFuncInterface func = new CalculatorFuncInterfaceImpl();
        int result = func.add(1, 2);
        System.out.println(result);
        System.out.println(func.multiply(15, 10));
        System.out.println(CalculatorFuncInterface.pi);
        CalculatorFuncInterface.display();
        CalculatorFuncInterface.displayMessage();

    }
}
