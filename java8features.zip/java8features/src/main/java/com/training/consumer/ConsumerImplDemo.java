package com.training.consumer;

import java.util.function.Consumer;

public class ConsumerImplDemo {
    public static void main(String[] args) {
        Consumer<Integer> consumer = new ConsumerImpl() ;
        consumer.accept(1);
        consumer.accept(2);
        consumer.accept(3);
        consumer.accept(4);
        consumer.accept(5);
        //System.out.println(consumer);
    }
}
