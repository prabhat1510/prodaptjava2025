package com.training.consumer;

import java.util.function.Consumer;

public class ConsumerAnother implements Consumer<String> {

    @Override
    public void accept(String s) {
        if(!s.isEmpty()){
            System.out.println(s);
        }else{
            System.out.println("It's an empty string.");
        }
    }
}
