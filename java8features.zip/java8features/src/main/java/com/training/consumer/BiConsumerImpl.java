package com.training.consumer;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class BiConsumerImpl implements BiConsumer<Integer, String> {
    @Override
    public void accept(Integer key, String value) {
        Map<Integer,String> map = new HashMap<Integer,String>();
        map.put(key,value);
        System.out.println(map);
    }
}
