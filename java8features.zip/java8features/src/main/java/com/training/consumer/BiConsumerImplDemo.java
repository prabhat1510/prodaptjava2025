package com.training.consumer;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class BiConsumerImplDemo {
    public static void main(String[] args) {
        BiConsumerImpl biConsumerImpl= new BiConsumerImpl();
        biConsumerImpl.accept(111,"Sweety");
        biConsumerImpl.accept(112,"Aprupshree");
        biConsumerImpl.accept(113,"Bakar Nigam");
        biConsumerImpl.accept(114,"Sahana Bharadwaj");
        biConsumerImpl.accept(115,"Gauri");
        biConsumerImpl.accept(116,"Sneha");
        biConsumerImpl.accept(117,"Tri Dhawan");
        System.out.println("******************************************");
        Map<String,Integer> map =new HashMap<>();
        BiConsumer<String,Integer> biConsumer =(b,i)->{

            map.put(b,i);
            //System.out.println(map);
        };
        biConsumer.accept("Sweety",111);
        biConsumer.accept("Aprupshree",1112);
        biConsumer.accept("Bakar Nigam",1113);
        biConsumer.accept("Sneha",1114);
        biConsumer.accept("Tri Dhawan",1115);
        biConsumer.accept("Gauri",1116);
        biConsumer.accept("Sneha",1117);
        biConsumer.accept("Vishal",1118);
        System.out.println(map);
    }
}
