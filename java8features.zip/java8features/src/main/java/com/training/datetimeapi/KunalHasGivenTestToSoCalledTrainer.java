package com.training.datetimeapi;

import java.time.LocalDate;

public class KunalHasGivenTestToSoCalledTrainer {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        System.out.println(localDate);
        //On 15th September which day of the week
        LocalDate localDate1 = LocalDate.of(2025,9,15);
        System.out.println(localDate1);
        System.out.println(localDate1.getDayOfWeek());
        //localDate1.getMonth();
        System.out.println(localDate1.getDayOfMonth());
        System.out.println(localDate1.getMonthValue());
        System.out.println(localDate1.getMonth());
    }
}
