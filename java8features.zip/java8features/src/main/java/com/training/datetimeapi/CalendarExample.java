package com.training.datetimeapi;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class CalendarExample {
    public static void main(String[] args) {
        Calendar cal = Calendar.getInstance();
        System.out.println(cal.get(Calendar.YEAR));
        System.out.println(cal.get(Calendar.MONTH));
        System.out.println(cal.get(Calendar.DAY_OF_MONTH));
        System.out.println(cal.get(Calendar.HOUR_OF_DAY));
        System.out.println(cal.get(Calendar.MINUTE));
        System.out.println(cal.get(Calendar.SECOND));
        System.out.println(cal.getTime());
        System.out.println(cal.getTimeZone());
        System.out.println(cal.get(Calendar.ERA));
        System.out.println("********************************************");
        Calendar cal2 = Calendar.getInstance();
        System.out.println(cal2.getTime());
        //getTimeInMillis gives the ms elapsed since January 1 1970 - epoch date
        System.out.println(cal2.getTimeInMillis());
        System.out.println(cal2.getTimeZone());
        System.out.println(Calendar.AM_PM);
        System.out.println(Calendar.DST_OFFSET);

        System.out.println("********************************************");
        //Date to LocalDate and vice versa
        Date dt = cal.getTime();
        //We should never use Date methods as they are deprecated
        // LocalDate lDate = LocalDate.of(dt.getYear(), dt.getDay(), dt.getMonth());
        LocalDate lDate = LocalDate.of(cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH), cal.get(Calendar.DATE));
        System.out.println(lDate);


    }
}
