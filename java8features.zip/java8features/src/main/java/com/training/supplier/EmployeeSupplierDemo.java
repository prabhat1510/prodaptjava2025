package com.training.supplier;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.function.Supplier;

public class EmployeeSupplierDemo {
    public static void main(String[] args) {
        //Lambda Expression
        Supplier<? extends Employee> s =()->new Employee("Rakesh");
        //Using lambda expression we are implementing Supplier Functional Interface
        System.out.println(s);
        System.out.println(s.get());
        Employee e = supplierFactory(s);
        System.out.println(e);
    }
    //This is a higher order function or method which accepts as lambda expression as an argument
    public static Employee supplierFactory(Supplier<? extends Employee> s) {
        Employee employee= s.get();
        if(employee.getName() == null || "".equals(employee.getName())) {
            employee.setName("default");
        }
        employee.setSalary(BigDecimal.ONE);
        employee.setStartDate(LocalDate.of(2016, 10, 15));
        return employee;
    }
}
